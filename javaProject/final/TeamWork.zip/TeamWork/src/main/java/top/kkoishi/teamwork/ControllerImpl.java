package top.kkoishi.teamwork;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public final class ControllerImpl {
    @FXML
    private GridPane root;


}